// ignore_for_file: unused_import, unused_field

import 'package:flutter/material.dart';
import 'package:pramuditha_uts3/page/list_page.dart';
import 'package:pramuditha_uts3/page/pertemuan_page.dart';
import 'package:pramuditha_uts3/page/profile_page.dart';

class Pertemuan {
  final String title;
  final String subtitle;

  Pertemuan({required this.title, required this.subtitle});
}

class ListPage extends StatefulWidget {
  const ListPage({super.key});

  @override
  State<ListPage> createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  int currentPage = 0;

  final List<Widget> _pages = [ProfilePage(), ListPage()];

  final List<Pertemuan> pertemuan = [
    Pertemuan(title: 'Pertemuan 1', subtitle: 'Materi 1 - Pengenalan Android'),
    Pertemuan(title: 'Pertemuan 2', subtitle: 'Materi 2 - Widget & Button'),
    Pertemuan(title: 'Pertemuan 3', subtitle: 'Materi 3 - Activity & Intent'),
    Pertemuan(title: 'Pertemuan 4', subtitle: 'Materi 4 - Toast & AlertDialog'),
    Pertemuan(title: 'Pertemuan 5', subtitle: 'Materi 5 - ListView'),
    Pertemuan(title: 'Pertemuan 6', subtitle: 'Materi 6 - Checkbox'),
    Pertemuan(title: 'Pertemuan 7', subtitle: 'Materi 7 - Navigation Button'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("MOBILE PROGRAMMING - Learning Materials"),
        backgroundColor: Colors.greenAccent, // pastel blue
      ),
      body: ListView.builder(
        itemCount: pertemuan.length,
        itemBuilder: (context, index) {
          final pertemuanItem = pertemuan[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.list),
              title: Text(pertemuanItem.title),
              subtitle: Text(pertemuanItem.subtitle),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder:
                        (context) => PertemuanPage(pertemuan: pertemuanItem),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
