// ignore_for_file: unused_import, unused_field
import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int currentPage = 0;
  final List<Widget> _pages = [ProfilePage(key: null), ProfilePage(key: null)];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent,
        title: const Text("PROFILE"),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.greenAccent, width: 3),
                    image: const DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage("../images/ugo.jpg"),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Nama:',
                  style: TextStyle(fontSize: 16, color: Colors.greenAccent),
                ),
                const Text(
                  'Muhamad Pramuditha',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 30),
                const Text(
                  'NIM:',
                  style: TextStyle(fontSize: 16, color: Colors.greenAccent),
                ),
                const Text(
                  '231011700981',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Kelas:',
                  style: TextStyle(fontSize: 16, color: Colors.greenAccent),
                ),
                const Text(
                  '04SIFP002',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Prodi:',
                  style: TextStyle(fontSize: 16, color: Colors.greenAccent),
                ),
                const Text(
                  'Sistem Informasi',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
