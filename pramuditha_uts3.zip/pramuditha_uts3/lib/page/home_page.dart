import 'package:flutter/material.dart';

class BerandaPage extends StatefulWidget {
  const BerandaPage({super.key});

  @override
  State<BerandaPage> createState() => _BerandaPageState();
}

class _BerandaPageState extends State<BerandaPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent,
        title: const Text("HOME"),
      ),
      body: Container(
        child: const Center(
          child: Text(
            "Welcome to the Official HyugoLearning Website!",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.greenAccent, // supaya teks kelihatan di atas gambar
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
//𝖂𝖊𝖑𝖈𝖔𝖒𝖊 𝖙𝖔 𝖙𝖍𝖊 𝕺𝖋𝖋𝖎𝖈𝖎𝖆𝖑 𝕳𝖞𝖚𝖌𝖔 𝕾𝖙𝖔𝖗𝖊 𝖂𝖊𝖇𝖘𝖎𝖙𝖊!