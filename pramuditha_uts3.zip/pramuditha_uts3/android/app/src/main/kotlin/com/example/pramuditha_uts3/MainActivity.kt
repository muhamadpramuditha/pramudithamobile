package com.example.pramuditha_uts3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
